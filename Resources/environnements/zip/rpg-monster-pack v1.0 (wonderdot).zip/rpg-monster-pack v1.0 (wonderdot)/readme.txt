WONDERDOT - RPG Monster Pack

License : https://www.gamedevmarket.net/terms-conditions/#pro-licence

===========================================================

v1.0 ------------------------------------------------------

-Giant Bat
-Giant Rat
-Giant Spider
-Goblin
-Goblin Sniper
-Orc
-Slime
-Troll
-Arrow projectile

===========================================================

Thank you for your support!

-Pita

silverdeluxe.tumblr.com
twitter.com/pita_akm